import{a as c,b as p}from"./eAn2giST.js";import{t as n}from"./DUAhQ_zu.js";import{s as t}from"./CM7rfxNA.js";import{p as a}from"./BOHS37UX.js";var v=p(`<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25
            2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0
            0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5
            0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5
            0a48.667 48.667 0 0 0-7.5 0"></path></svg>`);function w(m,r){let e=a(r,"opacity",3,.9),i=a(r,"width",3,"1.5rem"),s=a(r,"color",3,"hsl(var(--error))");var o=v();t(o,"stroke-width",2),n(()=>{t(o,"stroke",s()),t(o,"width",i()),t(o,"opacity",e())}),c(m,o)}export{w as I};
