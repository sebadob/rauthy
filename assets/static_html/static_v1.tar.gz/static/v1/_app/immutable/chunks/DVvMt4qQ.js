import{a as c,d as p}from"./VJ_63d1q.js";import{bi as n}from"./C15Oh9JW.js";import{s as t}from"./D-hK732q.js";import{p as e}from"./cF_6ATGa.js";var v=p(`<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M20.25 6.375c0 2.278-3.694 4.125-8.25 4.125S3.75 8.653 3.75 6.375m16.5
        0c0-2.278-3.694-4.125-8.25-4.125S3.75 4.097 3.75 6.375m16.5 0v11.25c0 2.278-3.694
        4.125-8.25 4.125s-8.25-1.847-8.25-4.125V6.375m16.5 0v3.75m-16.5-3.75v3.75m16.5 0v3.75C20.25
        16.153 16.556 18 12 18s-8.25-1.847-8.25-4.125v-3.75m16.5 0c0 2.278-3.694 4.125-8.25
        4.125s-8.25-1.847-8.25-4.125"></path></svg>`);function k(i,r){let a=e(r,"opacity",3,.9),m=e(r,"width",3,"1.5rem"),s=e(r,"color",3,"currentColor");var o=v();t(o,"stroke-width",2),n(()=>{t(o,"stroke",s()),t(o,"width",m()),t(o,"opacity",a())}),c(i,o)}export{k as I};
