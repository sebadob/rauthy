import{h as s,b as t,d as h}from"./CqevfShI.js";import{B as i}from"./Fx6zEkEr.js";function k(a,r,e){s&&t();var n=new i(a);h(()=>{var o=r();n.ensure(o,e)})}export{k};
