import{P as s}from"./DTPHzq9M.js";let t=s({});function i(){return{set(r,e){t[r]=e},trigger(r,e){t[r]?.(e)}}}export{i as u};
