import{n as s}from"./CGedpXPc.js";let t=s({});function i(){return{set(r,e){t[r]=e},trigger(r,e){t[r]?.(e)}}}export{i as u};
