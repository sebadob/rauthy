import{P as g}from"./K-sNbfMr.js";let t=g({});function s(){return{set(r,e){console.log("setting trigger",r),t[r]=e},trigger(r,e){t[r]?.(e)}}}export{s as u};
