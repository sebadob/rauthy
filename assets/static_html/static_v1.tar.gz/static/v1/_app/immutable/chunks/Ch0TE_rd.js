import{M as g}from"./XuHO3QDp.js";let t=g({});function s(){return{set(r,e){console.log("setting trigger",r),t[r]=e},trigger(r,e){t[r]?.(e)}}}export{s as u};
