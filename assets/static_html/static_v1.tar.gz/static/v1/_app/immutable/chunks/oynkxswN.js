import{F as e}from"./Ceh69RMu.js";async function f(t){let i=`/auth/v1/search?ty=${t.ty}&idx=${t.idx}&q=${t.q}`;return t.limit&&(i+=`$limit=${t.limit}`),await e(i)}export{f};
