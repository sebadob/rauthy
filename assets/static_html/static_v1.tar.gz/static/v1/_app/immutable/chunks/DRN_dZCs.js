import{f as e}from"./C0hPq3vt.js";async function c(t){let i=`/auth/v1/search?ty=${t.ty}&idx=${t.idx}&q=${t.q}`;return t.limit&&(i+=`$limit=${t.limit}`),await e(i)}export{c as f};
