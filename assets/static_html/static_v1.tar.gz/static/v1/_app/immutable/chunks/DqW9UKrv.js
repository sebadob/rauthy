import{h as s,b as t,d as h}from"./oH6L3LKb.js";import{B as i}from"./yEwGTkbD.js";function k(a,r,e){s&&t();var n=new i(a);h(()=>{var o=r();n.ensure(o,e)})}export{k};
