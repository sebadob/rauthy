import{P as s}from"./BpIhm5yx.js";let t=s({});function i(){return{set(r,e){t[r]=e},trigger(r,e){t[r]?.(e)}}}export{i as u};
