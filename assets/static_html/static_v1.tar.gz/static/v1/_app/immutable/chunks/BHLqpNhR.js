import{n as s}from"./KFTWTpC-.js";let t=s({});function i(){return{set(r,e){t[r]=e},trigger(r,e){t[r]?.(e)}}}export{i as u};
