import{n as s}from"./CPJIaX3T.js";let t=s({});function i(){return{set(r,e){t[r]=e},trigger(r,e){t[r]?.(e)}}}export{i as u};
