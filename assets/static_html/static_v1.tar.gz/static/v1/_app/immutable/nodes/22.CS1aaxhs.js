import"../chunks/DDwxewIm.js";import{U as p}from"../chunks/7U7L5kTI.js";function e(o){p(o,{})}export{e as component};
