import"../chunks/NZTpNUN0.js";import{E as r}from"../chunks/BELvFrs1.js";function m(o){r(o,{})}export{m as component};
