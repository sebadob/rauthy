import"../chunks/DsnmJJEf.js";import{U as p}from"../chunks/DuS3-cU_.js";function e(o){p(o,{})}export{e as component};
