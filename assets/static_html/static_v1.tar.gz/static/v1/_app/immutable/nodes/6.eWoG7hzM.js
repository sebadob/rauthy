import"../chunks/CGuIsVtu.js";import{U as p}from"../chunks/ChTS9iCE.js";function e(o){p(o,{})}export{e as component};
