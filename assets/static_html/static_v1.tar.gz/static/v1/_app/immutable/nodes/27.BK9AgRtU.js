import"../chunks/CGuIsVtu.js";import{E as r}from"../chunks/B7SHmme9.js";function m(o){r(o,{})}export{m as component};
