import"../chunks/DsnmJJEf.js";import{E as r}from"../chunks/DuQD7Yif.js";function m(o){r(o,{})}export{m as component};
