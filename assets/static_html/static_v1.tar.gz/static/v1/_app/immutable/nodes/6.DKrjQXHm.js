import"../chunks/DsnmJJEf.js";import{U as p}from"../chunks/CJha2QmH.js";function e(o){p(o,{})}export{e as component};
