import"../chunks/NZTpNUN0.js";import{v as t,$ as r}from"../chunks/BitPNVvj.js";import{U as a}from"../chunks/CczHJqSU.js";function p(o){t(e=>{r.title="Rauthy Users"}),a(o,{})}export{p as component};
