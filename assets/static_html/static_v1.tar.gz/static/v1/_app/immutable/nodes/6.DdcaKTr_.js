import"../chunks/eAn2giST.js";import{U as p}from"../chunks/DOriFbKT.js";function e(o){p(o,{})}export{e as component};
