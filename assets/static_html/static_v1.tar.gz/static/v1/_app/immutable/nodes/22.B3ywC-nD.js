import"../chunks/WPfuLYU5.js";import{U as p}from"../chunks/BhW_d-rH.js";function e(o){p(o,{})}export{e as component};
