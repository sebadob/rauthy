import"../chunks/B1U2fhvE.js";import{E as r}from"../chunks/DlBonQy-.js";function m(o){r(o,{})}export{m as component};
