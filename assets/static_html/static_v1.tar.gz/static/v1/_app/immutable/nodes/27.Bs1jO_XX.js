import"../chunks/BjX9mUlx.js";import{E as r}from"../chunks/B7DNZ0a4.js";function m(o){r(o,{})}export{m as component};
