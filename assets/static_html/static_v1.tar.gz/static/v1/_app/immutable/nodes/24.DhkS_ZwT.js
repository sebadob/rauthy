import"../chunks/DsnmJJEf.js";import{v as t,$ as r}from"../chunks/BpIhm5yx.js";import{U as a}from"../chunks/j1bWr8bM.js";function p(o){t(e=>{r.title="Rauthy Users"}),a(o,{})}export{p as component};
