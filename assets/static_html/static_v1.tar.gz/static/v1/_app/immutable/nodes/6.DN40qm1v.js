import"../chunks/BjX9mUlx.js";import{U as p}from"../chunks/HrHCFDQs.js";function e(o){p(o,{})}export{e as component};
