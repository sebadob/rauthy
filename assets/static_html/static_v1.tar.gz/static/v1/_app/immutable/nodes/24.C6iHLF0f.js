import"../chunks/DDwxewIm.js";import{E as r}from"../chunks/BLLzsbmx.js";function m(o){r(o,{})}export{m as component};
