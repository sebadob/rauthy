import"../chunks/DsnmJJEf.js";import{E as r}from"../chunks/C-G-nsA0.js";function m(o){r(o,{})}export{m as component};
