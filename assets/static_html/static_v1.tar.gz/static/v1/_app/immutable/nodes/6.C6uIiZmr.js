import"../chunks/DsnmJJEf.js";import{U as p}from"../chunks/DIKNoZqz.js";function e(o){p(o,{})}export{e as component};
