import"../chunks/NZTpNUN0.js";import{U as p}from"../chunks/IPq3qw93.js";function e(o){p(o,{})}export{e as component};
