import"../chunks/D_Vw9jbo.js";import{U as p}from"../chunks/B4_MA73s.js";function e(o){p(o,{})}export{e as component};
