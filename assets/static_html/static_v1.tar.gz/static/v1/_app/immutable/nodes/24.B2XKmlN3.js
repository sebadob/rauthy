import"../chunks/DDwxewIm.js";import{E as r}from"../chunks/D3u05EXA.js";function m(o){r(o,{})}export{m as component};
