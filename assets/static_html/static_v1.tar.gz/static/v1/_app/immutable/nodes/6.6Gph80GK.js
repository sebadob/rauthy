import"../chunks/CGuIsVtu.js";import{U as p}from"../chunks/CedgMy-j.js";function e(o){p(o,{})}export{e as component};
