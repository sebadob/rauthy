import"../chunks/DsnmJJEf.js";import{v as t,$ as r}from"../chunks/D4Cquf23.js";import{U as a}from"../chunks/FI6ur-WG.js";function p(o){t(e=>{r.title="Rauthy Users"}),a(o,{})}export{p as component};
