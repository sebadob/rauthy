import"../chunks/DsnmJJEf.js";import{U as p}from"../chunks/Cp5LGely.js";function e(o){p(o,{})}export{e as component};
