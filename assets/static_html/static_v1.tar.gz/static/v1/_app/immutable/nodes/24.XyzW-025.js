import"../chunks/DsnmJJEf.js";import{v as t,$ as r}from"../chunks/BaUnVK2Y.js";import{U as a}from"../chunks/BkPifYE0.js";function p(o){t(e=>{r.title="Rauthy Users"}),a(o,{})}export{p as component};
