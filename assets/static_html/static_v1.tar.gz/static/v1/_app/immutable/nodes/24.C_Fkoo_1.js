import"../chunks/DsnmJJEf.js";import{v as t,$ as r}from"../chunks/Bv_0XPzu.js";import{U as a}from"../chunks/DuS3-cU_.js";function p(o){t(e=>{r.title="Rauthy Users"}),a(o,{})}export{p as component};
