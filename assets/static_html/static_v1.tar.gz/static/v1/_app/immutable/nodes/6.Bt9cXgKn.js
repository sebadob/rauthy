import"../chunks/VJ_63d1q.js";import{U as p}from"../chunks/8GSx6Kde.js";function e(o){p(o,{})}export{e as component};
