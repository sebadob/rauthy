import"../chunks/CGuIsVtu.js";import{E as r}from"../chunks/hB1MIy2a.js";function m(o){r(o,{})}export{m as component};
