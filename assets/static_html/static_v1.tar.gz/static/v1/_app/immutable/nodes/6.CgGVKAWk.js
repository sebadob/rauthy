import"../chunks/DsnmJJEf.js";import{U as p}from"../chunks/FI6ur-WG.js";function e(o){p(o,{})}export{e as component};
