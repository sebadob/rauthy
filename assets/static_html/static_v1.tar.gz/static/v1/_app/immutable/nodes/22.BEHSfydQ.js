import"../chunks/WPfuLYU5.js";import{U as p}from"../chunks/BrXLWiiC.js";function e(o){p(o,{})}export{e as component};
