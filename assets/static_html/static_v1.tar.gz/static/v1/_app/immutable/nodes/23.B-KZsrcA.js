import"../chunks/NZTpNUN0.js";import{o as t,$ as r}from"../chunks/XuHO3QDp.js";import{U as a}from"../chunks/IPq3qw93.js";function p(o){t(e=>{r.title="Rauthy Users"}),a(o,{})}export{p as component};
