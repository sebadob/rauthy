import"../chunks/WPfuLYU5.js";import{E as r}from"../chunks/BALXvQDN.js";function m(o){r(o,{})}export{m as component};
