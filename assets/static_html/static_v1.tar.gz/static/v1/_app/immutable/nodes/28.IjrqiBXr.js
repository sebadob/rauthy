import"../chunks/VJ_63d1q.js";import{E as r}from"../chunks/DDEVxyfi.js";function m(o){r(o,{})}export{m as component};
