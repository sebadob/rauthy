import"../chunks/DDwxewIm.js";import{U as p}from"../chunks/5WXzJ7DP.js";function e(o){p(o,{})}export{e as component};
