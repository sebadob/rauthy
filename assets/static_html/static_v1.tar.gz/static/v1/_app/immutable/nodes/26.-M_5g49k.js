import"../chunks/BmgWm1LD.js";import{E as r}from"../chunks/BWwiZtQa.js";function m(o){r(o,{})}export{m as component};
