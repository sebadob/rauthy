import"../chunks/CGuIsVtu.js";import{E as r}from"../chunks/CJ72qc2L.js";function m(o){r(o,{})}export{m as component};
