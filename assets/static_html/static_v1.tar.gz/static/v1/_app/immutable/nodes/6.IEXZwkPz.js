import"../chunks/DsnmJJEf.js";import{U as p}from"../chunks/j1bWr8bM.js";function e(o){p(o,{})}export{e as component};
