import"../chunks/DNX4pL8G.js";import{U as p}from"../chunks/DWHUp6LP.js";function e(o){p(o,{})}export{e as component};
