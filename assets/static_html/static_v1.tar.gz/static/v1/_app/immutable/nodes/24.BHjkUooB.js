import"../chunks/DDwxewIm.js";import{E as r}from"../chunks/cOn7r4mw.js";function m(o){r(o,{})}export{m as component};
