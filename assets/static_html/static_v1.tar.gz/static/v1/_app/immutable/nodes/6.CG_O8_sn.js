import"../chunks/CGuIsVtu.js";import{U as p}from"../chunks/Dqse_7e2.js";function e(o){p(o,{})}export{e as component};
