import"../chunks/DNX4pL8G.js";import{U as p}from"../chunks/Do7ft1Lh.js";function e(o){p(o,{})}export{e as component};
