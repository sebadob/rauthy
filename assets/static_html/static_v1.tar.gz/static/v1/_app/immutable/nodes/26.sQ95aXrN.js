import"../chunks/DsnmJJEf.js";import{E as r}from"../chunks/COUrX8hg.js";function m(o){r(o,{})}export{m as component};
