import"../chunks/NZTpNUN0.js";import{U as p}from"../chunks/BpzuAomO.js";function e(o){p(o,{})}export{e as component};
