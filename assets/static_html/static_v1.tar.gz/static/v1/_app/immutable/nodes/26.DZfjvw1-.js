import"../chunks/DsnmJJEf.js";import{E as r}from"../chunks/1403uOfv.js";function m(o){r(o,{})}export{m as component};
