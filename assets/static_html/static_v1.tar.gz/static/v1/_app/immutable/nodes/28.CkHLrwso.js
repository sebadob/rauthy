import"../chunks/eAn2giST.js";import{E as r}from"../chunks/DVeE8L1o.js";function m(o){r(o,{})}export{m as component};
