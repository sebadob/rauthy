import"../chunks/DsnmJJEf.js";import{U as p}from"../chunks/BkPifYE0.js";function e(o){p(o,{})}export{e as component};
