import"../chunks/DsnmJJEf.js";import{E as r}from"../chunks/8tv4f96d.js";function m(o){r(o,{})}export{m as component};
