import"../chunks/BjX9mUlx.js";import{E as r}from"../chunks/1fr7M87u.js";function m(o){r(o,{})}export{m as component};
