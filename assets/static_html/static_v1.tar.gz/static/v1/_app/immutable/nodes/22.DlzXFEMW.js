import"../chunks/DDwxewIm.js";import{U as p}from"../chunks/ZTXuiZgC.js";function e(o){p(o,{})}export{e as component};
