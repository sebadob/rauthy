import"../chunks/DsnmJJEf.js";import{U as p}from"../chunks/vHKid2wu.js";function e(o){p(o,{})}export{e as component};
