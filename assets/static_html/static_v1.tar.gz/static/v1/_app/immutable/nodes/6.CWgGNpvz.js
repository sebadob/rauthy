import"../chunks/DNX4pL8G.js";import{U as p}from"../chunks/BFiUIcBZ.js";function e(o){p(o,{})}export{e as component};
