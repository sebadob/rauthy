import"../chunks/D_Vw9jbo.js";import{E as r}from"../chunks/DZi1W3Zm.js";function m(o){r(o,{})}export{m as component};
