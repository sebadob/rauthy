import"../chunks/D_Vw9jbo.js";import{U as p}from"../chunks/htXBWRek.js";function e(o){p(o,{})}export{e as component};
