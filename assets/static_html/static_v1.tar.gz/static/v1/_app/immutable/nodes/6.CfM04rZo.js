import"../chunks/BmgWm1LD.js";import{U as p}from"../chunks/DeXYK2hY.js";function e(o){p(o,{})}export{e as component};
