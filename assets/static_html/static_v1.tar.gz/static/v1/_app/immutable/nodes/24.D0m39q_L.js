import"../chunks/WPfuLYU5.js";import{E as r}from"../chunks/DSfqdg2t.js";function m(o){r(o,{})}export{m as component};
