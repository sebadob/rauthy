import"../chunks/BjX9mUlx.js";import{U as p}from"../chunks/DjAy-djQ.js";function e(o){p(o,{})}export{e as component};
