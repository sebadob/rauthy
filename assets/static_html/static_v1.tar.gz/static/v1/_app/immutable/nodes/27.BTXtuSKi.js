import"../chunks/DNX4pL8G.js";import{E as r}from"../chunks/9LtZtAIY.js";function m(o){r(o,{})}export{m as component};
