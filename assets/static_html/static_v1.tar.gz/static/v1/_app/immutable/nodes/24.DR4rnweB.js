import"../chunks/DsnmJJEf.js";import{v as t,$ as r}from"../chunks/DTPHzq9M.js";import{U as a}from"../chunks/vHKid2wu.js";function p(o){t(e=>{r.title="Rauthy Users"}),a(o,{})}export{p as component};
