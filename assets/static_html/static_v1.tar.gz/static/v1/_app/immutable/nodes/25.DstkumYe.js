import"../chunks/DsnmJJEf.js";import{E as r}from"../chunks/REEOh0cw.js";function m(o){r(o,{})}export{m as component};
