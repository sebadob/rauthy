import"../chunks/DsnmJJEf.js";import{U as p}from"../chunks/qP8PQZJM.js";function e(o){p(o,{})}export{e as component};
