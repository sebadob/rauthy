import"../chunks/BjX9mUlx.js";import{U as p}from"../chunks/DbQwE951.js";function e(o){p(o,{})}export{e as component};
