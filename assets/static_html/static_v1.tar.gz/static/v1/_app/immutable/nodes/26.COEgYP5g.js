import"../chunks/DsnmJJEf.js";import{E as r}from"../chunks/Bks7Xzsw.js";function m(o){r(o,{})}export{m as component};
