import"../chunks/BjX9mUlx.js";import{E as r}from"../chunks/Dbw1eUHg.js";function m(o){r(o,{})}export{m as component};
