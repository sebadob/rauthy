import"../chunks/eAn2giST.js";import{E as r}from"../chunks/B9N97--x.js";function m(o){r(o,{})}export{m as component};
