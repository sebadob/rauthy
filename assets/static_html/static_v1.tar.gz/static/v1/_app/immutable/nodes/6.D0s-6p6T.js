import"../chunks/-EGwAxaf.js";import{U as p}from"../chunks/_Wal5UzU.js";function e(o){p(o,{})}export{e as component};
