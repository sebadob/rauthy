import"../chunks/B1U2fhvE.js";import{U as p}from"../chunks/PjI0p95u.js";function e(o){p(o,{})}export{e as component};
