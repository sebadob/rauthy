import{l as o,a as r}from"../chunks/Bm-TJu9u.js";export{o as load_css,r as start};
