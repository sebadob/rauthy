import{l as o,a as r}from"../chunks/7eOHU5_b.js";export{o as load_css,r as start};
