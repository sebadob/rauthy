import{l as o,s as r}from"../chunks/BxVMbpY8.js";export{o as load_css,r as start};
