import{l as o,a as r}from"../chunks/BkK7B1gI.js";export{o as load_css,r as start};
