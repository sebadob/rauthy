import{l as o,a as r}from"../chunks/Bje1U2Xh.js";export{o as load_css,r as start};
