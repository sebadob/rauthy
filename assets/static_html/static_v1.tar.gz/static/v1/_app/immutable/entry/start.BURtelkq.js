import{l as o,a as r}from"../chunks/DlV7FiL-.js";export{o as load_css,r as start};
