import{l as o,a as r}from"../chunks/CZj6epbp.js";export{o as load_css,r as start};
