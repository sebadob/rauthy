import{l as o,a as r}from"../chunks/CQf7FxPu.js";export{o as load_css,r as start};
