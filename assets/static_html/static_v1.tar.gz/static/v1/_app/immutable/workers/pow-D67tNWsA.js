const s=import("./chunks/DGaQLJAD.js");onmessage=o=>{s.then(e=>{postMessage(e.pow_work_wasm(o.data)),self.close()})};onclose=()=>{console.log("PoW WebWorker closed")};
