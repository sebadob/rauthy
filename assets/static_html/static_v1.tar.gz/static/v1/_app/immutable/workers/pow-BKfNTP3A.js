const s=import("./chunks/BpEXknEx.js");onmessage=o=>{s.then(e=>{postMessage(e.pow_work_wasm(o.data)),self.close()})};onclose=()=>{console.log("PoW WebWorker closed")};
