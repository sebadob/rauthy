import{a as t}from"../chunks/entry.8balB3It.js";export{t as start};
