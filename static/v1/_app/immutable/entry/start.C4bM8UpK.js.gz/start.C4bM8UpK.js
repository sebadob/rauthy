import{a as t}from"../chunks/entry.CxfygF9O.js";export{t as start};
