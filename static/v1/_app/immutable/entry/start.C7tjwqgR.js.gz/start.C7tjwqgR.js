import{a as t}from"../chunks/entry.J1kODerE.js";export{t as start};
