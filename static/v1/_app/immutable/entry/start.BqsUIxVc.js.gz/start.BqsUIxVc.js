import{a as t}from"../chunks/entry.N1G99onN.js";export{t as start};
