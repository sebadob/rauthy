import{a as t}from"../chunks/entry.F_pkk_jj.js";export{t as start};
