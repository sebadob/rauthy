import{a as t}from"../chunks/entry.8OaWG8sl.js";export{t as start};
