import{a as t}from"../chunks/entry.6c8SoCeg.js";export{t as start};
