import{a as t}from"../chunks/entry.C492xHI4.js";export{t as start};
