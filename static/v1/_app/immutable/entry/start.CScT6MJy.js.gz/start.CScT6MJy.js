import{a as t}from"../chunks/entry.Bg4crcSB.js";export{t as start};
