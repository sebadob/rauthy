import{a as t}from"../chunks/entry.2kN-MiJh.js";export{t as start};
