import{a as t}from"../chunks/entry.ctgv5XMZ.js";export{t as start};
