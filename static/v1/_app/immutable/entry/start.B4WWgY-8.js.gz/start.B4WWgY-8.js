import{a as t}from"../chunks/entry.CI-DSOoj.js";export{t as start};
