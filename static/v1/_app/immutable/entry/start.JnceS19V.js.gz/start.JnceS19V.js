import{a as t}from"../chunks/entry.BnN9tDt-.js";export{t as start};
