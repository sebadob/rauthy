import{a as t}from"../chunks/entry.Dx9T2rCu.js";export{t as start};
