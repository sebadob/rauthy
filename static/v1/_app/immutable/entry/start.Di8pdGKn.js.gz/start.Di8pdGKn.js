import{a as t}from"../chunks/entry.CsH5nKMI.js";export{t as start};
