import{a as t}from"../chunks/entry.Ddy6icaf.js";export{t as start};
