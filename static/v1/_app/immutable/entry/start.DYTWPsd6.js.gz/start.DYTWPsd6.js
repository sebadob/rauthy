import{a as t}from"../chunks/entry.Dryhts4A.js";export{t as start};
