import{a as t}from"../chunks/entry.D8frxmGq.js";export{t as start};
