import{a as t}from"../chunks/entry.DTN3-12j.js";export{t as start};
