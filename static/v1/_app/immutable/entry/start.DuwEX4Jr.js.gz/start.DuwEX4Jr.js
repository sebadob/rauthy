import{a as t}from"../chunks/entry.Col7vTVz.js";export{t as start};
