import{a as t}from"../chunks/entry.CZTtOFZM.js";export{t as start};
