import{a as t}from"../chunks/entry.idKXET8J.js";export{t as start};
