import { n, a as l } from "./D8nUqfqE.js";
import { t as c } from "./D-nwkJyM.js";
import { s as t } from "./D_HYGYLR.js";
import { p as e } from "./2rFDT0Lm.js";
var m = n('<svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path></svg>');
function u(a, r) {
  let i = e(r, "opacity", 3, 0.9), p = e(r, "width", 3, "1.5rem"), s = e(r, "color", 3, "hsl(var(--error))");
  var o = m();
  t(o, "stroke-width", 2), c(() => {
    t(o, "width", p()), t(o, "color", s()), t(o, "opacity", i());
  }), l(a, o);
}
export {
  u as I
};
