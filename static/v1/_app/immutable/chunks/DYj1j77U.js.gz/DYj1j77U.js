import { t as g, a as _ } from "./BxmJRzoY.js";
import { p as R, j as c, f as k, a as M, l as T, k as e, s as r, c as p, r as l, t as O } from "./w0HvPX0p.js";
import { s as h } from "./BzP2S3Z_.js";
import { i as j } from "./iO9_dPNE.js";
import { L as w } from "./DAiQTto5.js";
import { M as A } from "./DKM0QPz5.js";
import { C as D } from "./QNragXLc.js";
import "./DM69BKKN.js";
import { T as $ } from "./BdDmaO9S.js";
import { T as U, a as X } from "./B21bTIl7.js";
import { T as q } from "./B1f0afjj.js";
import "./C8YTstTD.js";
var y = g('<div class="flex-col"><h1> </h1> <br> <p> </p> <!> <!> <!></div>'), z = g("<!> <!> <!>", 1);
function ar(x, b) {
  R(b, true);
  let a = c(""), o = c("");
  var n = z(), v = k(n);
  $(v, { id: U, get value() {
    return e(a);
  }, set value(t) {
    T(a, t, true);
  } });
  var d = r(v, 2);
  $(d, { id: X, get value() {
    return e(o);
  }, set value(t) {
    T(o, t, true);
  } });
  var C = r(d, 2);
  A(C, { children: (t, B) => {
    D(t, { children: (E, F) => {
      var s = y(), i = p(s), L = p(i, true);
      l(i);
      var m = r(i, 4), P = p(m, true);
      l(m);
      var f = r(m, 2);
      j(f, (G) => {
      });
      var u = r(f, 2);
      q(u, { absolute: true });
      var S = r(u, 2);
      w(S, { absolute: true }), l(s), O(() => {
        h(L, e(a)), h(P, e(o));
      }), _(E, s);
    } });
  } }), _(x, n), M();
}
export {
  ar as E
};
