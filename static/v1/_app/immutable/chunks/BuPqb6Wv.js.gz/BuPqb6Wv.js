import { n as s, a as m } from "./YHhP1LbZ.js";
import { t as l } from "./Ck6jKiur.js";
import { s as o } from "./BTaFr7HN.js";
import { p as e } from "./DZP54pO_.js";
var c = s('<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5"></path></svg>');
function u(a, r) {
  let i = e(r, "opacity", 3, 0.9), p = e(r, "width", 3, "1.5rem"), n = e(r, "color", 3, "currentColor");
  var t = c();
  o(t, "stroke-width", 2), l(() => {
    o(t, "stroke", n()), o(t, "width", p()), o(t, "opacity", i());
  }), m(a, t);
}
export {
  u as I
};
