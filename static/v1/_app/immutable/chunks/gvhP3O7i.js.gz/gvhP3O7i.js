import { d as s, a as t } from "./CWf9OOFK.js";
import { f as e } from "./nlANaGLT.js";
import { i as n } from "./DOjUa9u5.js";
import { I as p } from "./DYRiKtW9.js";
import { I as l } from "./DJ6IvX5N.js";
function C(a, c) {
  var r = s(), m = e(r);
  {
    var f = (o) => {
      p(o, { color: "hsl(var(--action))" });
    }, i = (o) => {
      l(o, { color: "hsl(var(--error))" });
    };
    n(m, (o) => {
      c.checked ? o(f) : o(i, false);
    });
  }
  t(a, r);
}
export {
  C
};
