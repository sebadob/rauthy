import { t as o, a as s } from "./CWf9OOFK.js";
import { c as i, r as n } from "./nlANaGLT.js";
import { s as p } from "./BgMuVWsk.js";
var v = o('<div class="svelte-vtwvgl"><!></div>');
function c(r, e) {
  var t = v(), a = i(t);
  p(a, () => e.children), n(t), s(r, t);
}
export {
  c as C
};
