import { t as g, a as _ } from "./CWf9OOFK.js";
import { p as k, f as M, a as O, l as c, k as T, j as e, s as r, c as m, r as l, t as j } from "./nlANaGLT.js";
import { s as h } from "./BmMHVVX3.js";
import { i as w } from "./DOjUa9u5.js";
import { p as x } from "./5u5qd9TD.js";
import { L as y } from "./xD9JfGV5.js";
import { M as A } from "./BDnQQV_p.js";
import { C as D } from "./DA40Z_in.js";
import { T as $ } from "./C4fNG2bJ.js";
import { T as U, a as X } from "./B21bTIl7.js";
import { T as q } from "./Afb0E4F7.js";
import "./BEQMYyDu.js";
var z = g('<div class="flex-col"><h1> </h1> <br> <p> </p> <!> <!> <!></div>'), B = g("<!> <!> <!>", 1);
function or(b, C) {
  k(C, true);
  let a = T(""), o = T("");
  var n = B(), v = M(n);
  $(v, { id: U, get value() {
    return e(a);
  }, set value(t) {
    c(a, x(t));
  } });
  var f = r(v, 2);
  $(f, { id: X, get value() {
    return e(o);
  }, set value(t) {
    c(o, x(t));
  } });
  var E = r(f, 2);
  A(E, { children: (t, F) => {
    D(t, { children: (L, G) => {
      var s = z(), i = m(s), P = m(i, true);
      l(i);
      var p = r(i, 4), S = m(p, true);
      l(p);
      var d = r(p, 2);
      w(d, (H) => {
      });
      var u = r(d, 2);
      q(u, { absolute: true });
      var R = r(u, 2);
      y(R, { absolute: true }), l(s), j(() => {
        h(P, e(a)), h(S, e(o));
      }), _(L, s);
    } });
  } }), _(b, n), O();
}
export {
  or as E
};
