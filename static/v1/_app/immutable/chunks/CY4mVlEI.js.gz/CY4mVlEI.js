import { d as e, a as f } from "./YHhP1LbZ.js";
import { p as i, f as p, a as n } from "./Ck6jKiur.js";
import { i as l } from "./7JDmqCCW.js";
import { I as h } from "./CWz_piBP.js";
import { I as v } from "./DREqFFqR.js";
function _(c, r) {
  i(r, true);
  var a = e(), s = p(a);
  {
    var m = (o) => {
      h(o, { color: "hsl(var(--action))" });
    }, t = (o) => {
      v(o, { color: "hsl(var(--error))" });
    };
    l(s, (o) => {
      r.checked ? o(m) : o(t, false);
    });
  }
  f(c, a), n();
}
export {
  _ as C
};
