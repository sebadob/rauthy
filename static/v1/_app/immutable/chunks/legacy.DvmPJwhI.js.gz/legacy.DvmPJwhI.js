import{a5 as a}from"./index-client.Ds4XgiuL.js";a();
