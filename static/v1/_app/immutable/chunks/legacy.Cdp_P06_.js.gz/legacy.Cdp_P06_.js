import{i as a}from"./index-client.CzqVbBUo.js";a();
