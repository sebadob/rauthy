import { t as e, a as o } from "./BH6NCLk-.js";
import { c as i, r as n } from "./CvlvO1XB.js";
import { s as p } from "./-T201g_q.js";
var d = e('<div class="content svelte-ss6zf"><!></div>');
function f(r, s) {
  var t = d(), a = i(t);
  p(a, () => s.children), n(t), o(r, t);
}
export {
  f as C
};
