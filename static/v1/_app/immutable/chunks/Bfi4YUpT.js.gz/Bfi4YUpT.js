import { t as e, a as o } from "./DLBGyKVC.js";
import { c as i, r as n } from "./CmQi0fbH.js";
import { s as p } from "./71gCR-8F.js";
var d = e('<div class="content svelte-ss6zf"><!></div>');
function f(r, s) {
  var t = d(), a = i(t);
  p(a, () => s.children), n(t), o(r, t);
}
export {
  f as C
};
