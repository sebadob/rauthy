import { t as o, a as s } from "./YHhP1LbZ.js";
import { c as i, r as n } from "./Ck6jKiur.js";
import { s as p } from "./9ksWc3Vn.js";
var v = o('<div class="svelte-vtwvgl"><!></div>');
function c(r, e) {
  var t = v(), a = i(t);
  p(a, () => e.children), n(t), s(r, t);
}
export {
  c as C
};
