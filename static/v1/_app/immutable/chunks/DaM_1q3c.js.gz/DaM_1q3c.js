import { t as e, a as i } from "./DKC5GJ29.js";
import { c as o, r as m } from "./BveBAmlr.js";
import { s as n } from "./Dv-Q3FDX.js";
var p = e('<main class="svelte-103rzrg"><!></main>');
function f(r, s) {
  var a = p(), t = o(a);
  n(t, () => s.children), m(a), i(r, a);
}
export {
  f as M
};
