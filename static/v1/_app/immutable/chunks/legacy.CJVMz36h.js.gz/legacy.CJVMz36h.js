import{i as a}from"./index-client.C1uYfxHd.js";a();
