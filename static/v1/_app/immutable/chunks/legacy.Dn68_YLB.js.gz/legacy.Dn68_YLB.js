import{P as a}from"./runtime.BsghBUX9.js";a();
