import { d as s, a as t } from "./BH6NCLk-.js";
import { f as e } from "./CvlvO1XB.js";
import { i as n } from "./BUO_AUgz.js";
import { I as p } from "./Nks81rMs.js";
import { I as l } from "./Vi3uK7uO.js";
function C(a, c) {
  var r = s(), m = e(r);
  {
    var f = (o) => {
      p(o, { color: "hsl(var(--action))" });
    }, i = (o) => {
      l(o, { color: "hsl(var(--error))" });
    };
    n(m, (o) => {
      c.checked ? o(f) : o(i, false);
    });
  }
  t(a, r);
}
export {
  C
};
