import{i as a}from"./index-client.Cqn5bTAA.js";a();
