import { j as s, l as r, k as u } from "./w0HvPX0p.js";
const a = "false";
let e = s(a === "true");
function o() {
  return { get() {
    return u(e);
  }, set(t) {
    r(e, t, true);
  } };
}
export {
  o as u
};
