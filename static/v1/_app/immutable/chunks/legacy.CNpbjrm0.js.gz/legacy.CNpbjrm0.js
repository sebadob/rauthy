import{i as a}from"./index-client.wsxBsMrC.js";a();
