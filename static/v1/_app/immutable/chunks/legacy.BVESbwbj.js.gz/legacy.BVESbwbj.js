import{P as a}from"./runtime.BONl2e88.js";a();
