import { t as e, a as i } from "./D8nUqfqE.js";
import { c as o, r as m } from "./D-nwkJyM.js";
import { s as n } from "./ivlJJTAR.js";
var p = e('<main class="svelte-1w3gfbz"><!></main>');
function d(r, s) {
  var a = p(), t = o(a);
  n(t, () => s.children), m(a), i(r, a);
}
export {
  d as M
};
