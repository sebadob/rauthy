import { n as s, a as l } from "./DLBGyKVC.js";
import { t as c } from "./CmQi0fbH.js";
import { s as t } from "./DOlUUCkJ.js";
import { p as e } from "./DNJm3-SG.js";
var m = s('<svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5"></path></svg>');
function u(a, r) {
  let i = e(r, "opacity", 3, 0.9), n = e(r, "width", 3, "1.5rem"), p = e(r, "color", 3, "currentColor");
  var o = m();
  t(o, "stroke-width", 2), c(() => {
    t(o, "width", n()), t(o, "color", p()), t(o, "opacity", i());
  }), l(a, o);
}
export {
  u as I
};
