import { t as o, a as s } from "./BH6NCLk-.js";
import { c as i, r as n } from "./CvlvO1XB.js";
import { s as p } from "./-T201g_q.js";
var v = o('<div class="svelte-vtwvgl"><!></div>');
function c(r, e) {
  var t = v(), a = i(t);
  p(a, () => e.children), n(t), s(r, t);
}
export {
  c as C
};
