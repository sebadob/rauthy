import { t as o, a as s } from "./DLBGyKVC.js";
import { c as i, r as n } from "./CmQi0fbH.js";
import { s as p } from "./71gCR-8F.js";
var v = o('<div class="svelte-vtwvgl"><!></div>');
function c(r, e) {
  var t = v(), a = i(t);
  p(a, () => e.children), n(t), s(r, t);
}
export {
  c as C
};
