import{l as s,k as r,j as u}from"./DXTz3Rbt.js";const a="false";let e=r(a==="true");function o(){return{get(){return u(e)},set(t){s(e,t,!0)}}}export{o as u};
