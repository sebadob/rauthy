import { d as m, h as d, b as f, g as c, i as n, m as u, o as v, H as g, q as y, u as b, v as p } from "./Ck6jKiur.js";
import { b as o, c as R } from "./YHhP1LbZ.js";
function q(h, _, w, k, H) {
  var s = h, r = "", e;
  m(() => {
    if (r === (r = _() ?? "")) {
      d && f();
      return;
    }
    e !== void 0 && (p(e), e = void 0), r !== "" && (e = c(() => {
      if (d) {
        n.data;
        for (var a = f(), t = a; a !== null && (a.nodeType !== 8 || a.data !== ""); ) t = a, a = u(a);
        if (a === null) throw v(), g;
        o(n, t), s = y(a);
        return;
      }
      var l = r + "", i = R(l);
      o(b(i), i.lastChild), s.before(i);
    }));
  });
}
export {
  q as h
};
