import { d as f, E as u, g as c, a6 as d, v as l, h as p, i as g, j as m, l as s, k as h } from "./w0HvPX0p.js";
function _(i, o, ...r) {
  var a = i, n = d, e;
  f(() => {
    n !== (n = o()) && (e && (l(e), e = null), e = c(() => n(a, ...r)));
  }, u), p && (a = g);
}
let t = m("");
function v() {
  typeof document < "u" ? s(t, document.documentElement.lang.slice(0, 2).toLowerCase(), true) : s(t, "en");
}
function y() {
  return h(t);
}
export {
  v as i,
  _ as s,
  y as u
};
