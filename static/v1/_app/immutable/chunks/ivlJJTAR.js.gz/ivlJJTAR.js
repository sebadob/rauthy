import { d as f, E as p, g as c, a8 as u, v as d, h as l, i as m, l as s, k as g, j as h } from "./D-nwkJyM.js";
import { p as y } from "./BiI21XkS.js";
function v(o, i, ...r) {
  var t = o, n = u, e;
  f(() => {
    n !== (n = i()) && (e && (d(e), e = null), e = c(() => n(t, ...r)));
  }, p), l && (t = m);
}
let a = g("");
function L() {
  typeof document < "u" ? s(a, y(document.documentElement.lang.slice(0, 2).toLowerCase())) : s(a, "en");
}
function T() {
  return h(a);
}
export {
  L as i,
  v as s,
  T as u
};
