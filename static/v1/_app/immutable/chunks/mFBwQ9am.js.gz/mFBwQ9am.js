import { n as s, a as m } from "./YHhP1LbZ.js";
import { t as l } from "./Ck6jKiur.js";
import { s as o } from "./BTaFr7HN.js";
import { p as a } from "./DZP54pO_.js";
var c = s('<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75"></path></svg>');
function u(e, r) {
  let i = a(r, "opacity", 3, 0.9), n = a(r, "width", 3, "1.5rem"), p = a(r, "color", 3, "currentColor");
  var t = c();
  o(t, "stroke-width", 2), l(() => {
    o(t, "stroke", p()), o(t, "width", n()), o(t, "opacity", i());
  }), m(e, t);
}
export {
  u as I
};
