import { d as e, a as f } from "./BxmJRzoY.js";
import { p as i, f as p, a as n } from "./w0HvPX0p.js";
import { i as l } from "./iO9_dPNE.js";
import { I as h } from "./CTshzOVc.js";
import { I as v } from "./QCVRj9pj.js";
function _(c, r) {
  i(r, true);
  var a = e(), s = p(a);
  {
    var m = (o) => {
      h(o, { color: "hsl(var(--action))" });
    }, t = (o) => {
      v(o, { color: "hsl(var(--error))" });
    };
    l(s, (o) => {
      r.checked ? o(m) : o(t, false);
    });
  }
  f(c, a), n();
}
export {
  _ as C
};
