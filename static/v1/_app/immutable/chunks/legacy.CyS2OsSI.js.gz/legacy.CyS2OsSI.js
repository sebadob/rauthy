import{i as a}from"./index-client.Bsb9hq-M.js";a();
