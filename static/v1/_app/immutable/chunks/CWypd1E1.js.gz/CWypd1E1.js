import { s as e, p as r } from "./-aVU66dM.js";
const t = { get error() {
  return r.error;
}, get route() {
  return r.route;
}, get status() {
  return r.status;
}, get url() {
  return r.url;
} };
e.updated.check;
const u = t;
export {
  u as p
};
