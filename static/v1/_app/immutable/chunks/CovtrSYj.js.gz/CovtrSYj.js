import { t as e, a as o } from "./YHhP1LbZ.js";
import { c as i, r as n } from "./Ck6jKiur.js";
import { s as p } from "./9ksWc3Vn.js";
var d = e('<div class="content svelte-ss6zf"><!></div>');
function f(r, s) {
  var t = d(), a = i(t);
  p(a, () => s.children), n(t), o(r, t);
}
export {
  f as C
};
