import{a5 as a}from"./index-client.Di99sPv0.js";a();
