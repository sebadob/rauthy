import{a5 as a}from"./index-client.CVQra9Cu.js";a();
