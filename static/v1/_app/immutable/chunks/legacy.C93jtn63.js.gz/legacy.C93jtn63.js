import{a3 as a}from"./index-client.ijM6xFk7.js";a();
