import{z as a}from"./index-client.BTDbhFDr.js";a();
