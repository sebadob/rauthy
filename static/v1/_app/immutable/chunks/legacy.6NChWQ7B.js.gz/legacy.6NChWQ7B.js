import{i as a}from"./index-client.LkyNpeLM.js";a();
