import { l as s, k as r, j as o } from "./CmQi0fbH.js";
import { p as a } from "./B_ggA-0N.js";
const u = "false";
let t = r(u === "true");
function f() {
  return { get() {
    return o(t);
  }, set(e) {
    s(t, a(e));
  } };
}
export {
  f as u
};
