import { d as s, a as t } from "./DKC5GJ29.js";
import { f as e } from "./BveBAmlr.js";
import { i as n } from "./D-uYoVwt.js";
import { I as p } from "./Cxysd5TC.js";
import { I as l } from "./B7o5HlxY.js";
function C(a, c) {
  var r = s(), m = e(r);
  {
    var f = (o) => {
      p(o, { color: "hsl(var(--action))" });
    }, i = (o) => {
      l(o, { color: "hsl(var(--error))" });
    };
    n(m, (o) => {
      c.checked ? o(f) : o(i, false);
    });
  }
  t(a, r);
}
export {
  C
};
