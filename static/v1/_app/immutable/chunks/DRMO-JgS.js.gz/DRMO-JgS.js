import { h as f, b as c, d as i, n as h, e as d, g as k, i as y, U as _ } from "./CmQi0fbH.js";
function v(n, s, t) {
  f && c();
  var e = n, r = _, a, o = h;
  i(() => {
    o(r, r = s()) && (a && d(a), a = k(() => t(e)));
  }), f && (e = y);
}
export {
  v as k
};
