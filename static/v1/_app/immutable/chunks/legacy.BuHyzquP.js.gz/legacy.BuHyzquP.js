import{i as a}from"./index-client.CGppiJvc.js";a();
