import { n as p, a as c } from "./DKC5GJ29.js";
import { t as l } from "./BveBAmlr.js";
import { s as t } from "./Dql74IOz.js";
import { p as e } from "./Db0ChEdV.js";
var m = p('<svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5"></path></svg>');
function k(a, r) {
  let i = e(r, "opacity", 3, 0.9), n = e(r, "width", 3, "1.5rem"), s = e(r, "color", 3, "hsl(var(--action))");
  var o = m();
  t(o, "stroke-width", 2), l(() => {
    t(o, "width", n()), t(o, "color", s()), t(o, "opacity", i());
  }), c(a, o);
}
export {
  k as I
};
