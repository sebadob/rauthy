import { t as e, a as i } from "./BH6NCLk-.js";
import { c as o, r as m } from "./CvlvO1XB.js";
import { s as n } from "./-T201g_q.js";
var p = e('<main class="svelte-1w3gfbz"><!></main>');
function d(r, s) {
  var a = p(), t = o(a);
  n(t, () => s.children), m(a), i(r, a);
}
export {
  d as M
};
