import { t as e, a as i } from "./BxmJRzoY.js";
import { c as o, r as m } from "./w0HvPX0p.js";
import { s as n } from "./DM69BKKN.js";
var p = e('<main class="svelte-103rzrg"><!></main>');
function f(r, s) {
  var a = p(), t = o(a);
  n(t, () => s.children), m(a), i(r, a);
}
export {
  f as M
};
