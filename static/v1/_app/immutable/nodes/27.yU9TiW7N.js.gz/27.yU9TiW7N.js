import "../chunks/BH6NCLk-.js";
import { E as r } from "../chunks/B51tO80P.js";
function m(o) {
  r(o, {});
}
export {
  m as component
};
