import "../chunks/DLBGyKVC.js";
import { E as r } from "../chunks/CvQ3UxxC.js";
function m(o) {
  r(o, {});
}
export {
  m as component
};
