import"../chunks/disclose-version.DZhRUPAc.js";import"../chunks/legacy.BuHyzquP.js";import{E as r}from"../chunks/Error.CsY9Wg-p.js";function t(o){r(o,{})}export{t as component};
