import { t as c, a as h } from "../chunks/BxmJRzoY.js";
import { p as u, f as v, t as l, a as g, s as x, c as e, r as s } from "../chunks/w0HvPX0p.js";
import { s as p } from "../chunks/BzP2S3Z_.js";
import { p as o } from "../chunks/DlEiqYXV.js";
var _ = c("<h1> </h1> <p> </p>", 1);
function k(m, f) {
  u(f, true);
  var r = _(), t = v(r), i = e(t, true);
  s(t);
  var a = x(t, 2), n = e(a, true);
  s(a), l(() => {
    var _a;
    p(i, o.status), p(n, (_a = o.error) == null ? void 0 : _a.message);
  }), h(m, r), g();
}
export {
  k as component
};
