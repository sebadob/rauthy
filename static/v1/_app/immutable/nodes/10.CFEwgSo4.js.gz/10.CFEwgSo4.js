import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.CJVMz36h.js";import{A as t}from"../chunks/AdminMainPre.B6a42Qjw.js";function e(o){t(o,{selected:"Docs"})}export{e as component};
