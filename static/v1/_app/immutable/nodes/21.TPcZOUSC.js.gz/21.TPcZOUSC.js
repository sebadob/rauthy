import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.CyS2OsSI.js";import{E as r}from"../chunks/Error.2EXHfbkg.js";function t(o){r(o,{})}export{t as component};
