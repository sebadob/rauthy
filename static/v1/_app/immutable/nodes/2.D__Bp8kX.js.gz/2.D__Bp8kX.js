import { d as vt, a as n, t as M, n as V, e as T } from "../chunks/D8nUqfqE.js";
import { p as ht, a5 as zt, l as b, k as H, f as Y, j as r, a as mt, c as h, r as d, t as p, a9 as kt, s as g, aa as st, a8 as U, a7 as E, aj as Pt, a6 as St } from "../chunks/D-nwkJyM.js";
import { s as j, e as bt, h as Tt } from "../chunks/DmLjbmU6.js";
import { i as tt } from "../chunks/C3XMhfdI.js";
import { h as Lt } from "../chunks/1rF6JvjJ.js";
import { s as dt } from "../chunks/ivlJJTAR.js";
import { p as B } from "../chunks/BiI21XkS.js";
import { b as gt } from "../chunks/Crgqrr3Z.js";
import { M as Et } from "../chunks/C-ghU9Ac.js";
import { a as ut, B as ct } from "../chunks/BUAPoI3e.js";
import { s as o, a as jt } from "../chunks/D_HYGYLR.js";
import { T as Mt } from "../chunks/DmGHSNVM.js";
import { L as At } from "../chunks/DJrws3yD.js";
import { p as Ct } from "../chunks/BsLhmaxX.js";
import { f as Bt, b as Ht } from "../chunks/emZtalxW.js";
import { A as Vt } from "../chunks/Ch0F_Zoj.js";
import { p as v } from "../chunks/2rFDT0Lm.js";
import { I as qt } from "../chunks/Dq3vuPfn.js";
import { u as _t, i as Ot } from "../chunks/DMJUG0wm.js";
import { S as Wt, k as pt, i as Zt, D as Nt } from "../chunks/DppGgfa0.js";
import { T as Ut } from "../chunks/g4HrlpfL.js";
import { u as Gt } from "../chunks/B899WTRX.js";
import { e as $t } from "../chunks/6MDunRKZ.js";
import { E as Rt } from "../chunks/CU527LE8.js";
import { u as Dt } from "../chunks/CMjKUQkH.js";
import { O as Kt } from "../chunks/Fz9KQU3M.js";
var Ft = M('<div class="ver upd svelte-4tal6i"><a target="_blank" class="svelte-4tal6i"> </a></div>'), Jt = M('<div class="ver svelte-4tal6i"> </div>');
function Qt(c, e) {
  ht(e, true);
  let a = H(void 0);
  zt(() => {
    l();
  });
  async function l() {
    let _ = await Bt("/auth/v1/version");
    _.body ? b(a, B(_.body)) : console.error(_.error);
  }
  var i = vt(), t = Y(i);
  {
    var x = (_) => {
      var I = vt(), A = Y(I);
      {
        var N = (y) => {
          var u = Ft(), k = h(u), L = h(k);
          d(k), d(u), p(() => {
            o(k, "href", r(a).latest_url), j(L, `v${r(a) ?? ""} \u26A0\uFE0F`);
          }), n(y, u);
        }, P = (y) => {
          var u = Jt(), k = h(u);
          d(u), p(() => j(k, `v${r(a).current ?? ""}`)), n(y, u);
        };
        tt(A, (y) => {
          r(a).update_available ? y(N) : y(P, false);
        });
      }
      n(_, I);
    };
    tt(t, (_) => {
      r(a) && _(x);
    });
  }
  n(c, i), mt();
}
var Xt = V(`<svg width="100%" height="100%" viewBox="0 0 512 138" version="1.1" xmlns="http://www.w3.org/2000/svg" xml:space="preserve" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:1.5;"><g transform="matrix(1,0,0,1,0,-11)"><g transform="matrix(1,0,0,1,0,-176)"><g transform="matrix(0.920325,0,0,1.84151,45.9279,26.459)"><rect x="27.741" y="151.57" width="200.517" height="10.148" style="fill:rgb(4,7,11);"></rect></g><g transform="matrix(1.93472,0,0,1.82732,8.35618,28.7533)"><rect x="33.307" y="97.15" width="94.693" height="54.42" style="fill:rgb(4,7,11);stroke:rgb(4,7,11);stroke-width:1.06px;"></rect></g><g transform="matrix(1.82732,0,0,1.82732,-160.822,70.1806)"><g transform="matrix(72,0,0,72,227.174,123.417)"></g><text x="128.982px" y="123.417px" style="font-family:'Calibri-Bold', 'Calibri', sans-serif;font-weight:700;font-size:72px;fill:white;">r<tspan x="152.994px 188.537px " y="123.417px 123.417px ">au</tspan></text></g><g transform="matrix(1,0,0,1.01617,-1.42109e-14,-5.24492)"><path d="M440.936,322.643L439.204,324.266L255.482,324.266L255.482,305.721L440.936,305.721L440.936,322.643Z" style="fill:url(#_Linear1);"></path></g><g transform="matrix(0.920191,0,0,1.84121,46.2464,-91.3383)"><rect x="27.741" y="151.57" width="200.517" height="10.148" style="fill:url(#_Linear2);"></rect></g><g transform="matrix(1.97598,0,0,1.84619,190.187,26.062)"><rect x="33.307" y="97.15" width="94.693" height="54.42" style="fill:rgb(43,65,107);"></rect></g><path d="M439.204,187.734L440.557,189.007L440.557,206.279L256,206.279L256,187.734L439.204,187.734Z" style="fill:rgb(43,65,107);"></path><g transform="matrix(1.82732,0,0,1.82732,-154.661,70.1806)"><g transform="matrix(72,0,0,72,323.045,123.417)"></g><text x="226.646px" y="123.417px" style="font-family:'Calibri-Bold', 'Calibri', sans-serif;font-weight:700;font-size:72px;fill:white;">th<tspan x="288.943px " y="123.417px ">y</tspan></text></g><g transform="matrix(2,0,0,2,0,0)"><path d="M219.602,93.867L256,128L219.602,162.133L219.602,93.867Z" style="fill:rgb(43,65,107);"></path></g><g transform="matrix(2,0,0,1.95739,0,3.99997)"><path d="M36.398,93.867L0,93.867L35.908,128.524L0,163.619L36.398,163.619" style="fill:rgb(4,7,11);"></path></g></g></g><defs><linearGradient id="_Linear1" x1="0" y1="0" x2="1" y2="0" gradientUnits="userSpaceOnUse" gradientTransform="matrix(185.454,0,0,18.5443,255.482,314.994)"><stop offset="0" style="stop-color:rgb(4,7,11);stop-opacity:1"></stop><stop offset="1" style="stop-color:rgb(43,65,107);stop-opacity:1"></stop></linearGradient><linearGradient id="_Linear2" x1="0" y1="0" x2="1" y2="0" gradientUnits="userSpaceOnUse" gradientTransform="matrix(200.517,0,0,10.1483,27.7414,156.645)"><stop offset="0" style="stop-color:rgb(4,7,11);stop-opacity:1"></stop><stop offset="1" style="stop-color:rgb(43,65,107);stop-opacity:1"></stop></linearGradient></defs></svg>`);
function Yt(c) {
  var e = Xt();
  n(c, e);
}
var te = M('<div class="compact svelte-7fczgn"><div class="iconCompact svelte-7fczgn"><!></div> <span class="svelte-7fczgn"><!></span></div>'), ee = M('<div class="wide svelte-7fczgn"><div class="iconWide svelte-7fczgn"><!></div> <div><!></div></div>');
function G(c, e) {
  const a = "/auth/v1/admin";
  let l = kt(() => e.compact ? "1.5rem" : "1.2rem"), i = kt(() => `${a}${e.route}${e.params}`);
  Vt(c, { get href() {
    return r(i);
  }, hideUnderline: true, get highlightIncludes() {
    return e.highlightIncludes;
  }, children: (t, x) => {
    var _ = vt(), I = Y(_);
    {
      var A = (P) => {
        var y = te(), u = h(y), k = h(u);
        dt(k, () => e.icon, () => r(l)), d(u);
        var L = g(u, 2), z = h(L);
        dt(z, () => e.children), d(L), d(y), n(P, y);
      }, N = (P) => {
        var y = ee(), u = h(y), k = h(u);
        dt(k, () => e.icon, () => r(l)), d(u);
        var L = g(u, 2), z = h(L);
        dt(z, () => e.children), d(L), d(y), p(() => ut(u, "width", r(l))), n(P, y);
      };
      tt(I, (P) => {
        e.compact ? P(A) : P(N, false);
      });
    }
    n(t, _);
  }, $$slots: { default: true } });
}
var re = V('<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"></path></svg>');
function oe(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = re();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var ae = V(`<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 12c0-1.232-.046-2.453-.138-3.662a4.006 4.006 0 0 0-3.7-3.7 48.678 48.678 0 0 0-7.324 0 4.006 4.006
            0 0 0-3.7 3.7c-.017.22-.032.441-.046.662M19.5 12l3-3m-3 3-3-3m-12 3c0 1.232.046 2.453.138 3.662a4.006 4.006
            0 0 0 3.7 3.7 48.656 48.656 0 0 0 7.324 0 4.006 4.006 0 0 0 3.7-3.7c.017-.22.032-.441.046-.662M4.5 12l3
            3m-3-3-3 3"></path></svg>`);
function ie(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = ae();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var ne = V(`<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-4.682-2.72m.94 3.198.001.031c0
            .225-.012.447-.037.666A11.944 11.944 0 0 1 12 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 0 1 6
            18.719m12 0a5.971 5.971 0 0 0-.941-3.197m0 0A5.995 5.995 0 0 0 12 12.75a5.995 5.995 0 0 0-5.058 2.772m0
            0a3 3 0 0 0-4.681 2.72 8.986 8.986 0 0 0 3.74.477m.94-3.197a5.971 5.971 0 0 0-.94 3.197M15 6.75a3 3 0 1
            1-6 0 3 3 0 0 1 6 0Zm6 3a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Zm-13.5 0a2.25 2.25 0 1 1-4.5 0 2.25
            2.25 0 0 1 4.5 0Z"></path></svg>`);
function se(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = ne();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var le = V('<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"></path></svg>');
function ve(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = le();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var ce = V(`<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5
            3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21"></path></svg>`);
function de(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = ce();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var ue = V('<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z"></path></svg>');
function he(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = ue();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var me = V('<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z"></path></svg>');
function fe(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = me();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var pe = V(`<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 9h3.75M15 12h3.75M15 15h3.75M4.5 19.5h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5
            4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 19.5zm6-10.125a1.875 1.875 0 11-3.75 0
            1.875 1.875 0 013.75 0zm1.294 6.336a6.721 6.721 0 01-3.17.789 6.721 6.721 0 01-3.168-.789 3.376
            3.376 0 016.338 0z"></path></svg>`);
function ge(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = pe();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var _e = V(`<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 0 0 5.454-1.31A8.967 8.967 0 0 1 18 9.75V9A6 6 0 0 0 6 9v.75a8.967 8.967
            0 0 1-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 0 1-5.714 0m5.714 0a3 3 0 1 1-5.714
            0"></path></svg>`);
function we(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = _e();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var ye = V('<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1121.75 8.25z"></path></svg>');
function xe(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = ye();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var ke = V(`<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15a4.5 4.5 0 0 0 4.5 4.5H18a3.75 3.75 0 0 0 1.332-7.257 3 3 0 0 0-3.758-3.848 5.25 5.25 0 0
            0-10.233 2.33A4.502 4.502 0 0 0 2.25 15Z"></path></svg>`);
function be(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = ke();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var Le = V('<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M11.42 15.17L17.25 21A2.652 2.652 0 0021 17.25l-5.877-5.877M11.42 15.17l2.496-3.03c.317-.384.74-.626 1.208-.766M11.42 15.17l-4.655 5.653a2.548 2.548 0 11-3.586-3.586l6.837-5.63m5.108-.233c.55-.164 1.163-.188 1.743-.14a4.5 4.5 0 004.486-6.336l-3.276 3.277a3.004 3.004 0 01-2.25-2.25l3.276-3.276a4.5 4.5 0 00-6.336 4.486c.091 1.076-.071 2.264-.904 2.95l-.102.085m-1.745 1.437L5.909 7.5H4.5L2.25 3.75l1.5-1.5L7.5 4.5v1.409l4.26 4.26m-1.745 1.437l1.745-1.437m6.615 8.206L15.75 15.75M4.867 19.125h.008v.008h-.008v-.008z"></path></svg>');
function Me(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = Le();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var Ae = V('<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25"></path></svg>');
function Ce(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = Ae();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var je = V(`<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 0 1-1.043 3.296 3.745
            3.745 0 0 1-3.296 1.043A3.745 3.745 0 0 1 12 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 0
            1-3.296-1.043 3.745 3.745 0 0 1-1.043-3.296A3.745 3.745 0 0 1 3 12c0-1.268.63-2.39 1.593-3.068a3.745
            3.745 0 0 1 1.043-3.296 3.746 3.746 0 0 1 3.296-1.043A3.746 3.746 0 0 1 12 3c1.268 0 2.39.63 3.068
            1.593a3.746 3.746 0 0 1 3.296 1.043 3.746 3.746 0 0 1 1.043 3.296A3.745 3.745 0 0 1 21 12Z"></path></svg>`);
function Be(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = je();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var Ie = V('<svg fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75"></path></svg>');
function ze(c, e) {
  let a = v(e, "opacity", 3, 0.9), l = v(e, "width", 3, "1.5rem"), i = v(e, "color", 3, "currentColor");
  var t = Ie();
  o(t, "stroke-width", 2), p(() => {
    o(t, "stroke", i()), o(t, "width", l()), o(t, "opacity", a());
  }), n(c, t);
}
var Pe = M('<span class="inner svelte-jr9y20"><!></span>'), Se = M('<span class="inner svelte-jr9y20"><!></span>'), Te = M("<div><!></div>"), Ee = M('<div class="logo svelte-jr9y20"><!></div> <div class="menu svelte-jr9y20"><!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!></div>', 1), He = M('<div class="logout svelte-jr9y20"><!></div>'), Ve = M('<!> <div class="theme svelte-jr9y20"><!></div> <!>', 1), qe = M('<div class="flex gap-05"><!> <!> <!></div> <div class="version svelte-jr9y20"><!></div>', 1), Oe = M('<div class="bottom svelte-jr9y20"><!></div>'), We = M('<nav id="mainNav" class="svelte-jr9y20"><div class="svelte-jr9y20"><div><div class="relative"><div class="absolute flex space-between navmod svelte-jr9y20"><div><!></div> <!></div></div> <!></div> <!></div></nav>');
function Ze(c, e) {
  ht(e, true);
  let a = _t(), l = H(false), i = H(""), t = H(false), x = H(true), _ = H(void 0);
  st(() => {
    b(i, B(Ct.url.search));
  }), st(() => {
    r(_) && r(_) < 600 && Ct.url && b(x, true);
  }), st(() => {
    b(x, B(r(_) && r(_) < 800 || false));
  }), st(() => {
    b(t, B(r(_) && r(_) < 1280 || false));
  });
  function I() {
    b(l, true);
  }
  function A() {
    setTimeout(() => {
      b(l, false);
    }, 1e3);
  }
  function N() {
    b(x, !r(x));
  }
  function P() {
    b(t, !r(t));
  }
  var y = We(), u = h(y), k = h(u), L = h(k), z = h(L), J = h(z), $ = h(J);
  ct($, { ariaControls: "mainNav", invisible: true, onclick: N, children: (C, S) => {
    var K = Pe(), rt = h(K);
    oe(rt, {}), d(K), n(C, K);
  }, $$slots: { default: true } }), d(J);
  var R = g(J, 2);
  {
    var et = (C) => {
      var S = Te(), K = h(S);
      ct(K, { invisible: true, onclick: P, children: (rt, at) => {
        var X = Se(), q = h(X);
        ie(q, {}), d(X), n(rt, X);
      }, $$slots: { default: true } }), d(S), n(C, S);
    };
    tt(R, (C) => {
      r(x) || C(et);
    });
  }
  d(z), d(L);
  var D = g(L, 2);
  {
    var w = (C) => {
      var S = Ee(), K = Y(S), rt = h(K);
      Yt(rt), d(K);
      var at = g(K, 2), X = h(at);
      G(X, { get compact() {
        return r(t);
      }, get params() {
        return r(i);
      }, route: "/users", icon: (s, m = U) => {
        fe(s, { get width() {
          return m();
        } });
      }, children: (s, m) => {
        E();
        var f = T();
        p(() => j(f, a.nav.users)), n(s, f);
      } });
      var q = g(X, 2);
      G(q, { get compact() {
        return r(t);
      }, get params() {
        return r(i);
      }, route: "/attributes", icon: (s, m = U) => {
        ve(s, { get width() {
          return m();
        } });
      }, children: (s, m) => {
        E();
        var f = T();
        p(() => j(f, a.nav.attributes)), n(s, f);
      } });
      var Z = g(q, 2);
      G(Z, { get compact() {
        return r(t);
      }, get params() {
        return r(i);
      }, route: "/clients", icon: (s, m = U) => {
        de(s, { get width() {
          return m();
        } });
      }, children: (s, m) => {
        E();
        var f = T();
        p(() => j(f, a.nav.clients)), n(s, f);
      } });
      var O = g(Z, 2);
      G(O, { get compact() {
        return r(t);
      }, get params() {
        return r(i);
      }, route: "/roles", icon: (s, m = U) => {
        Be(s, { get width() {
          return m();
        } });
      }, children: (s, m) => {
        E();
        var f = T();
        p(() => j(f, a.nav.roles)), n(s, f);
      } });
      var W = g(O, 2);
      G(W, { get compact() {
        return r(t);
      }, get params() {
        return r(i);
      }, route: "/groups", icon: (s, m = U) => {
        se(s, { get width() {
          return m();
        } });
      }, children: (s, m) => {
        E();
        var f = T();
        p(() => j(f, a.nav.groups)), n(s, f);
      } });
      var ot = g(W, 2);
      G(ot, { get compact() {
        return r(t);
      }, get params() {
        return r(i);
      }, route: "/scopes", icon: (s, m = U) => {
        ge(s, { get width() {
          return m();
        } });
      }, children: (s, m) => {
        E();
        var f = T();
        p(() => j(f, a.nav.scopes)), n(s, f);
      } });
      var nt = g(ot, 2);
      G(nt, { get compact() {
        return r(t);
      }, get params() {
        return r(i);
      }, route: "/sessions", icon: (s, m = U) => {
        he(s, { get width() {
          return m();
        } });
      }, children: (s, m) => {
        E();
        var f = T();
        p(() => j(f, a.nav.sessions)), n(s, f);
      } });
      var lt = g(nt, 2);
      G(lt, { get compact() {
        return r(t);
      }, get params() {
        return r(i);
      }, route: "/events", icon: (s, m = U) => {
        we(s, { get width() {
          return m();
        } });
      }, children: (s, m) => {
        E();
        var f = T();
        p(() => j(f, a.nav.events)), n(s, f);
      } });
      var ft = g(lt, 2);
      G(ft, { get compact() {
        return r(t);
      }, get params() {
        return r(i);
      }, route: "/blacklist", icon: (s, m = U) => {
        qt(s, { get width() {
          return m();
        }, color: "currentColor" });
      }, children: (s, m) => {
        E();
        var f = T();
        p(() => j(f, a.nav.blacklist)), n(s, f);
      } });
      var wt = g(ft, 2);
      G(wt, { get compact() {
        return r(t);
      }, get params() {
        return r(i);
      }, route: "/api_keys", icon: (s, m = U) => {
        xe(s, { get width() {
          return m();
        } });
      }, children: (s, m) => {
        E();
        var f = T();
        p(() => j(f, a.nav.apiKeys)), n(s, f);
      } });
      var yt = g(wt, 2);
      G(yt, { get compact() {
        return r(t);
      }, get params() {
        return r(i);
      }, route: "/providers", icon: (s, m = U) => {
        be(s, { get width() {
          return m();
        } });
      }, children: (s, m) => {
        E();
        var f = T();
        p(() => j(f, a.nav.providers)), n(s, f);
      } });
      var xt = g(yt, 2);
      G(xt, { get compact() {
        return r(t);
      }, get params() {
        return r(i);
      }, route: "/config/policy", highlightIncludes: "/config/", icon: (s, m = U) => {
        Me(s, { get width() {
          return m();
        } });
      }, children: (s, m) => {
        E();
        var f = T();
        p(() => j(f, a.nav.config)), n(s, f);
      } });
      var It = g(xt, 2);
      G(It, { get compact() {
        return r(t);
      }, get params() {
        return r(i);
      }, route: "/docs", icon: (s, m = U) => {
        Ce(s, { get width() {
          return m();
        } });
      }, children: (s, m) => {
        E();
        var f = T();
        p(() => j(f, a.nav.docs)), n(s, f);
      } }), d(at), n(C, S);
    };
    tt(D, (C) => {
      r(x) || C(w);
    });
  }
  d(k);
  var Q = g(k, 2);
  {
    var it = (C) => {
      var S = Oe();
      {
        const X = (q) => {
          var Z = He(), O = h(Z);
          ct(O, { invisible: true, onclick: () => Wt(), children: (W, ot) => {
            Ut(W, { text: "Logout", children: (nt, lt) => {
              ze(nt, {});
            }, $$slots: { default: true } });
          }, $$slots: { default: true } }), d(Z), n(q, Z);
        };
        var K = h(S);
        {
          var rt = (q) => {
            var Z = Ve(), O = Y(Z);
            X(O);
            var W = g(O, 2), ot = h(W);
            Mt(ot, {}), d(W);
            var nt = g(W, 2);
            At(nt, { openTop: true }), n(q, Z);
          }, at = (q) => {
            var Z = qe(), O = Y(Z), W = h(O);
            Mt(W, {});
            var ot = g(W, 2);
            At(ot, { openTop: true });
            var nt = g(ot, 2);
            X(nt), d(O);
            var lt = g(O, 2), ft = h(lt);
            Qt(ft, {}), d(lt), n(q, Z);
          };
          tt(K, (q) => {
            r(t) ? q(rt) : q(at, false);
          });
        }
        d(S);
      }
      n(C, S);
    };
    tt(Q, (C) => {
      r(x) || C(it);
    });
  }
  d(u), d(y), p(() => {
    o(y, "aria-hidden", r(x)), o(y, "data-compact", r(t)), o(z, "aria-hidden", !r(x) && !r(l));
  }), gt("innerWidth", (C) => b(_, B(C))), bt("mouseenter", y, I), bt("mouseleave", y, A), n(c, y), mt();
}
var Ne = M('<fieldset class="svelte-1vtgp8q"><legend class="font-label svelte-1vtgp8q"> </legend> <ul><li class="svelte-1vtgp8q">Info</li> <li class="svelte-1vtgp8q">Notice</li> <li class="svelte-1vtgp8q">Warning</li> <li class="svelte-1vtgp8q">Critical</li></ul></fieldset>');
function Ue(c, e) {
  ht(e, true);
  let a = Dt();
  var l = Ne(), i = h(l), t = h(i, true);
  d(i);
  var x = g(i, 2);
  let _;
  var I = h(x), A = g(I, 2), N = g(A, 2), P = g(N, 2);
  d(x), d(l), p((y, u, k, L) => {
    j(t, a.common.legend), _ = jt(x, 1, "svelte-1vtgp8q", null, _, { wide: e.wide }), ut(I, "border-color", y), ut(A, "border-color", u), ut(N, "border-color", k), ut(P, "border-color", L);
  }, [() => pt("info"), () => pt("notice"), () => pt("warning"), () => pt("critical")]), n(c, l), mt();
}
var Ge = M('<div role="none" id="events"><div class="upper"><div class="header svelte-1bsnz8"><div class="flex gap-10"><b>Events</b> <!></div> <!></div> <div class="data svelte-1bsnz8"></div></div> <!></div>');
function $e(c, e) {
  ht(e, true);
  const a = 50;
  let l = _t(), i = H(void 0), t = H(false), x = H(void 0), _ = H(B([])), I = H(B([])), A = H(B(Zt() && localStorage.getItem("eventLevel") || "info")), N = "";
  Pt(() => {
    var _a;
    (_a = r(x)) == null ? void 0 : _a.close();
  }), st(() => {
    r(i) && b(t, r(i) > 1680);
  }), st(() => {
    r(A) !== N && (N = r(A), y());
  }), st(() => {
    if (r(_)) switch (r(A)) {
      case "info":
        b(I, B(r(_)));
        break;
      case "notice":
        b(I, B(r(_).filter((w) => w.typ === "Test" || w.level === "notice" || w.level === "warning" || w.level === "critical")));
        break;
      case "warning":
        b(I, B(r(_).filter((w) => w.typ === "Test" || w.level === "warning" || w.level === "critical")));
        break;
      case "critical":
        b(I, B(r(_).filter((w) => w.typ === "Test" || w.level === "critical")));
        break;
    }
  });
  async function P() {
    await Ht("/auth/v1/events/test");
  }
  function y() {
    var _a, _b;
    localStorage.setItem("eventLevel", r(A)), ((_a = r(x)) == null ? void 0 : _a.readyState) !== 2 && ((_b = r(x)) == null ? void 0 : _b.close()), console.log("opening SSE stream"), b(x, B(new EventSource(`/auth/v1/events/stream?latest=${a}&level=${r(A).toLowerCase()}`))), r(x).onopen = () => {
      b(_, B([]));
    }, r(x).onerror = () => {
      console.error("SSE Events Stream closed");
    }, r(x).onmessage = (w) => {
      if (w.data) {
        let Q = JSON.parse(w.data);
        b(_, B([Q, ...r(_).slice(-499)]));
      }
    };
  }
  var u = Ge();
  let k;
  var L = h(u), z = h(L), J = h(z), $ = g(h(J), 2);
  Kt($, { get ariaLabel() {
    return l.events.eventLevel;
  }, options: Nt, borderless: true, get value() {
    return r(A);
  }, set value(w) {
    b(A, B(w));
  } }), d(J);
  var R = g(J, 2);
  ct(R, { level: 3, onclick: P, children: (w, Q) => {
    E();
    var it = T("Test");
    n(w, it);
  }, $$slots: { default: true } }), d(z);
  var et = g(z, 2);
  $t(et, 21, () => r(I), (w) => w.id, (w, Q) => {
    Rt(w, { get event() {
      return r(Q);
    } });
  }), d(et), d(L);
  var D = g(L, 2);
  Ue(D, { get wide() {
    return r(t);
  } }), d(u), p(() => k = jt(u, 1, "svelte-1bsnz8", null, k, { wide: r(t), narrow: !r(t) })), gt("innerWidth", (w) => b(i, B(w))), n(c, u), mt();
}
var Re = M('<div class="noAdmin svelte-drznxl"><div><div class="text svelte-drznxl"><!></div> <!></div></div>'), De = M('<div class="noAdmin svelte-drznxl"><div><div class="text svelte-drznxl"><!></div> <!></div></div>'), Ke = M('<div class="events"><!></div>'), Fe = M('<div class="content svelte-drznxl"><!></div> <!>', 1), Je = M("<!> <!>", 1);
function br(c, e) {
  ht(e, true), Ot();
  let a = _t(), l = Gt("admin"), i = H(void 0), t = H(false), x = H(false), _ = H(false);
  st(() => {
    var _a;
    let u = l.get();
    u && (!!((_a = u == null ? void 0 : u.roles) == null ? void 0 : _a.includes("rauthy_admin")) ? (b(t, true), I()) : b(x, true));
  });
  async function I() {
    (await Bt("/auth/v1/auth_check_admin")).status === 406 && b(_, true);
  }
  var A = vt();
  Tt((u) => {
    St.title = "Rauthy Admin";
  });
  var N = Y(A);
  {
    var P = (u) => {
      var k = Re(), L = h(k), z = h(L), J = h(z);
      Lt(J, () => a.error.noAdmin), d(z);
      var $ = g(z, 2);
      ct($, { onclick: () => window.location.href = "/auth/v1/account", children: (R, et) => {
        E();
        var D = T();
        p(() => j(D, a.common.account)), n(R, D);
      }, $$slots: { default: true } }), d(L), d(k), n(u, k);
    }, y = (u) => {
      var k = vt(), L = Y(k);
      {
        var z = ($) => {
          var R = De(), et = h(R), D = h(et), w = h(D);
          Lt(w, () => a.error.needsAdminRole), d(D);
          var Q = g(D, 2);
          ct(Q, { onclick: () => window.location.href = "/auth/v1/", children: (it, C) => {
            E();
            var S = T();
            p(() => j(S, a.common.back)), n(it, S);
          }, $$slots: { default: true } }), d(et), d(R), n($, R);
        }, J = ($) => {
          var R = vt(), et = Y(R);
          {
            var D = (w) => {
              var Q = Je(), it = Y(Q);
              Ze(it, {});
              var C = g(it, 2);
              Et(C, { children: (S, K) => {
                var rt = Fe(), at = Y(rt), X = h(at);
                dt(X, () => e.children), d(at);
                var q = g(at, 2);
                {
                  var Z = (O) => {
                    var W = Ke(), ot = h(W);
                    $e(ot, {}), d(W), n(O, W);
                  };
                  tt(q, (O) => {
                    r(i) && r(i) > 1024 && O(Z);
                  });
                }
                n(S, rt);
              } }), n(w, Q);
            };
            tt(et, (w) => {
              r(t) && w(D);
            }, true);
          }
          n($, R);
        };
        tt(L, ($) => {
          r(x) ? $(z) : $(J, false);
        }, true);
      }
      n(u, k);
    };
    tt(N, (u) => {
      r(_) ? u(P) : u(y, false);
    });
  }
  gt("innerWidth", (u) => b(i, B(u))), n(c, A), mt();
}
export {
  br as component
};
