import "../chunks/BH6NCLk-.js";
import { U as p } from "../chunks/BPcol6Mu.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
