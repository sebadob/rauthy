import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.Dmu0D13_.js";import{U as p}from"../chunks/Users.g8OiMzs0.js";function t(o){p(o,{})}export{t as component};
