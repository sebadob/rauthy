import "../chunks/YHhP1LbZ.js";
import { E as r } from "../chunks/BiJvfPj0.js";
function m(o) {
  r(o, {});
}
export {
  m as component
};
