import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.BVESbwbj.js";import{U as p}from"../chunks/Users.DENntGPm.js";function t(o){p(o,{})}export{t as component};
