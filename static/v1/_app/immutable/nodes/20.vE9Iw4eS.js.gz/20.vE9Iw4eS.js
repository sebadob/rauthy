import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.Dn68_YLB.js";import{E as r}from"../chunks/Error._4x1l89Z.js";function t(o){r(o,{})}export{t as component};
