import "../chunks/BxmJRzoY.js";
import { U as p } from "../chunks/GTpVA3Wq.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
