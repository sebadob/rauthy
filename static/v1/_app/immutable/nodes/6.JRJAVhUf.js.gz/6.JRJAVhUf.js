import "../chunks/DLBGyKVC.js";
import { U as p } from "../chunks/s8nzM7Mj.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
