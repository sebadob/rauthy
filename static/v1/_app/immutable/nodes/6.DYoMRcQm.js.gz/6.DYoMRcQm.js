import "../chunks/YHhP1LbZ.js";
import { U as p } from "../chunks/DZdMf8mL.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
