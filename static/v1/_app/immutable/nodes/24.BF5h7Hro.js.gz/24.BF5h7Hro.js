import "../chunks/BxmJRzoY.js";
import { E as r } from "../chunks/pBOErnZ4.js";
function m(o) {
  r(o, {});
}
export {
  m as component
};
