import "../chunks/BH6NCLk-.js";
import { E as r } from "../chunks/Cvi5ulFs.js";
function m(o) {
  r(o, {});
}
export {
  m as component
};
