import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.CiDis14V.js";import{E as r}from"../chunks/Error.UC8GRS5z.js";function t(o){r(o,{})}export{t as component};
