import "../chunks/BH6NCLk-.js";
import { E as r } from "../chunks/C-8adDJ4.js";
function m(o) {
  r(o, {});
}
export {
  m as component
};
