import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.pqhLE6I2.js";import{E as r}from"../chunks/Error.C3dHYNzg.js";function t(o){r(o,{})}export{t as component};
