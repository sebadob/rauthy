import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.Cdp_P06_.js";import{E as r}from"../chunks/Error.DXjVprxK.js";function t(o){r(o,{})}export{t as component};
