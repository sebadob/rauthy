import "../chunks/BxmJRzoY.js";
import { U as p } from "../chunks/DXoeHWZa.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
