import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.CyS2OsSI.js";import{A as t}from"../chunks/AdminMainPre.99DKZfTY.js";function e(o){t(o,{selected:"Docs"})}export{e as component};
