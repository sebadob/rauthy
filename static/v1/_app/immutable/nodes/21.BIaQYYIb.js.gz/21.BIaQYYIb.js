import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.BVESbwbj.js";import{E as r}from"../chunks/Error.BkvsSaAB.js";function t(o){r(o,{})}export{t as component};
