import"../chunks/disclose-version.DZhRUPAc.js";import"../chunks/legacy.BuHyzquP.js";import{A as t}from"../chunks/AdminMainPre.BC7y4hZJ.js";function e(o){t(o,{selected:"Docs"})}export{e as component};
