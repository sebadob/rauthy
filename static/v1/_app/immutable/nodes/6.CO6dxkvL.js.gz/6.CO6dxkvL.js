import "../chunks/BxmJRzoY.js";
import { U as p } from "../chunks/CE89mQ11.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
