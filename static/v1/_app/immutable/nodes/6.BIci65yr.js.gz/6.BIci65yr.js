import "../chunks/CWf9OOFK.js";
import { U as p } from "../chunks/CXntGsYq.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
