import "../chunks/D8nUqfqE.js";
import { E as r } from "../chunks/Iw5Xj1Ui.js";
function m(o) {
  r(o, {});
}
export {
  m as component
};
