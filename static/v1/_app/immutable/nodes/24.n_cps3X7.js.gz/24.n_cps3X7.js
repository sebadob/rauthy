import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.DvmPJwhI.js";import{E as r}from"../chunks/Error.Bsa2eS8l.js";function t(o){r(o,{})}export{t as component};
