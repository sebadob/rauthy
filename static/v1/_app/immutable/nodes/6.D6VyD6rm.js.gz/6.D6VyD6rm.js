import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.DtyiMpWz.js";import{U as p}from"../chunks/Users.BUOAhkxZ.js";function t(o){p(o,{})}export{t as component};
