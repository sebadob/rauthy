import"../chunks/DVyqXkF9.js";import{U as p}from"../chunks/DEOnfjKh.js";function e(o){p(o,{})}export{e as component};
