import "../chunks/BxmJRzoY.js";
import { E as r } from "../chunks/8Az7H6dy.js";
function m(o) {
  r(o, {});
}
export {
  m as component
};
