import "../chunks/DLBGyKVC.js";
import { U as p } from "../chunks/Dz7pjEE8.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
