import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.C93jtn63.js";import{E as r}from"../chunks/Error.DKYcRjlM.js";function t(o){r(o,{})}export{t as component};
