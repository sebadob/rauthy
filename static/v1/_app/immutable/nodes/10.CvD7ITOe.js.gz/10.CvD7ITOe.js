import"../chunks/disclose-version.C0dpEWi_.js";import"../chunks/legacy.6NChWQ7B.js";import{A as t}from"../chunks/AdminMainPre.CWDwXa4d.js";function e(o){t(o,{selected:"Docs"})}export{e as component};
