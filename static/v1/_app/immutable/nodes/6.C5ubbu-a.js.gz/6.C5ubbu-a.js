import"../chunks/DVyqXkF9.js";import{U as p}from"../chunks/DV3TsVEe.js";function e(o){p(o,{})}export{e as component};
