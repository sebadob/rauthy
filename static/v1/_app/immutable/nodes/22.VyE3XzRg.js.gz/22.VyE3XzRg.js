import "../chunks/DKC5GJ29.js";
import { U as p } from "../chunks/CVZhLbf8.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
