import "../chunks/BH6NCLk-.js";
import { U as p } from "../chunks/repg6D9j.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
