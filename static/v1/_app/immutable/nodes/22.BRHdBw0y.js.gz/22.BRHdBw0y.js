import"../chunks/disclose-version.BP4T4xdV.js";import{U as p}from"../chunks/Users.Zn5LNjgf.js";function t(o){p(o,{})}export{t as component};
