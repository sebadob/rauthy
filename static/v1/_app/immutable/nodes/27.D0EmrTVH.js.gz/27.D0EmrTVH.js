import"../chunks/DVyqXkF9.js";import{E as r}from"../chunks/Crbda40i.js";function m(o){r(o,{})}export{m as component};
