import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.DUFkTaXF.js";import{E as r}from"../chunks/Error.CIoPmUWl.js";function t(o){r(o,{})}export{t as component};
