import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.CJVMz36h.js";import{E as r}from"../chunks/Error.D_hrZquE.js";function t(o){r(o,{})}export{t as component};
