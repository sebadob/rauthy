import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.CWXZuyhS.js";import{E as r}from"../chunks/Error.BEXYSjnO.js";function t(o){r(o,{})}export{t as component};
