import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.BDl8PDwo.js";import{E as r}from"../chunks/Error.BY4TUX2n.js";function t(o){r(o,{})}export{t as component};
