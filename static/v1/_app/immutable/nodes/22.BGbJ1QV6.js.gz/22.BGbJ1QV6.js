import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.pqhLE6I2.js";import{U as p}from"../chunks/Users.DpLMJSd1.js";function t(o){p(o,{})}export{t as component};
