import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.DvmPJwhI.js";import{U as p}from"../chunks/Users.DjU9w7DZ.js";function t(o){p(o,{})}export{t as component};
