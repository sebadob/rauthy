import "../chunks/DKC5GJ29.js";
import { E as r } from "../chunks/DrpItC2r.js";
function m(o) {
  r(o, {});
}
export {
  m as component
};
