import { t as c, a as h } from "../chunks/BH6NCLk-.js";
import { p as u, f as v, t as l, a as g, s as x, c as e, r as s } from "../chunks/CvlvO1XB.js";
import { s as p } from "../chunks/CTI4QPiR.js";
import { p as o } from "../chunks/BDMwC9Hh.js";
var _ = c("<h1> </h1> <p> </p>", 1);
function k(m, f) {
  u(f, true);
  var r = _(), t = v(r), i = e(t, true);
  s(t);
  var a = x(t, 2), n = e(a, true);
  s(a), l(() => {
    var _a;
    p(i, o.status), p(n, (_a = o.error) == null ? void 0 : _a.message);
  }), h(m, r), g();
}
export {
  k as component
};
