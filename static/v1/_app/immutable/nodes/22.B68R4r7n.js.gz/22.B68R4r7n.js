import"../chunks/DVyqXkF9.js";import{U as p}from"../chunks/DQYv_DlZ.js";function e(o){p(o,{})}export{e as component};
