import "../chunks/D8nUqfqE.js";
import { U as p } from "../chunks/BfZLFYg4.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
