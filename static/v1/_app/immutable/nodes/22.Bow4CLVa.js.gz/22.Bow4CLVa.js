import "../chunks/BH6NCLk-.js";
import { U as p } from "../chunks/DWrxf3rR.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
