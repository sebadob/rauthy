import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.DUFkTaXF.js";import{U as p}from"../chunks/Users.EqefgBE_.js";function t(o){p(o,{})}export{t as component};
