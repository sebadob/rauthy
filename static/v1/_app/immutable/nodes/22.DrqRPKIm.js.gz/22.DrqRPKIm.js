import "../chunks/BxmJRzoY.js";
import { U as p } from "../chunks/w1NR0BX2.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
