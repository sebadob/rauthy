import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.DJEB66nf.js";import{E as r}from"../chunks/Error.uPLTyYQl.js";function t(o){r(o,{})}export{t as component};
