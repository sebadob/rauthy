import"../chunks/DiP_w2ew.js";import{E as r}from"../chunks/CpFvsSOf.js";function m(o){r(o,{})}export{m as component};
