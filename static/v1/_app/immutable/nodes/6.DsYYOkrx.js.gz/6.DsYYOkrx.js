import "../chunks/BxmJRzoY.js";
import { U as p } from "../chunks/BghfvpUE.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
