import "../chunks/DKC5GJ29.js";
import { E as r } from "../chunks/D2X7rwkb.js";
function m(o) {
  r(o, {});
}
export {
  m as component
};
