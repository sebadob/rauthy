import "../chunks/DKC5GJ29.js";
import { U as p } from "../chunks/CjN3FKvc.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
