import"../chunks/DVyqXkF9.js";import{E as r}from"../chunks/DEma75jW.js";function m(o){r(o,{})}export{m as component};
