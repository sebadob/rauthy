import"../chunks/disclose-version.BP4T4xdV.js";import{E as m}from"../chunks/Error.CZQd77GS.js";function r(o){m(o,{})}export{r as component};
