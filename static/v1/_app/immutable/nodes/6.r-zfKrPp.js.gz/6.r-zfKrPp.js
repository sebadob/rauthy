import "../chunks/BH6NCLk-.js";
import { U as p } from "../chunks/QubpoZo8.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
