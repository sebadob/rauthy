import"../chunks/disclose-version.C0dpEWi_.js";import"../chunks/legacy.6NChWQ7B.js";import{E as r}from"../chunks/Error.DP38dUwc.js";function t(o){r(o,{})}export{t as component};
