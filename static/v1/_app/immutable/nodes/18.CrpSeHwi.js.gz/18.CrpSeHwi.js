import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.Dn68_YLB.js";import{U as p}from"../chunks/Users.DQjgWw0O.js";function t(o){p(o,{})}export{t as component};
