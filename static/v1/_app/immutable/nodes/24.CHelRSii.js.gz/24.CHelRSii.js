import "../chunks/CWf9OOFK.js";
import { E as r } from "../chunks/CSMNKnun.js";
function m(o) {
  r(o, {});
}
export {
  m as component
};
