import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.Cdp_P06_.js";import{A as t}from"../chunks/AdminMainPre.BQ510M9M.js";function e(o){t(o,{selected:"Docs"})}export{e as component};
