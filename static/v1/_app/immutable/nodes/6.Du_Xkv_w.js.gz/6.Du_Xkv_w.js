import "../chunks/BH6NCLk-.js";
import { U as p } from "../chunks/CDXsSp4_.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
