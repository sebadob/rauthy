import "../chunks/BH6NCLk-.js";
import { U as p } from "../chunks/Cec0EAyV.js";
function e(o) {
  p(o, {});
}
export {
  e as component
};
