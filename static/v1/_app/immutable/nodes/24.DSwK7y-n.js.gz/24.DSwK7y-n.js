import "../chunks/BxmJRzoY.js";
import { E as r } from "../chunks/DYj1j77U.js";
function m(o) {
  r(o, {});
}
export {
  m as component
};
