import "../chunks/DLBGyKVC.js";
import { E as r } from "../chunks/BL0-mRKl.js";
function m(o) {
  r(o, {});
}
export {
  m as component
};
