import"../chunks/DiP_w2ew.js";import{U as p}from"../chunks/B78u8IEP.js";function e(o){p(o,{})}export{e as component};
