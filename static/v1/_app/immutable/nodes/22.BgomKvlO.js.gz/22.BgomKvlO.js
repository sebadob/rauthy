import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.C93jtn63.js";import{U as p}from"../chunks/Users.CKCZW6n7.js";function t(o){p(o,{})}export{t as component};
